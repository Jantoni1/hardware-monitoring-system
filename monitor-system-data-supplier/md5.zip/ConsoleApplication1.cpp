// ConsoleApplication1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "md5.h"

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	MD5 md5;

	//suma md5 dla stringa (zako�czony /0 )
	cout << md5.digestString("HELLO THERE I AM MD5!") << endl;

	//dla zwyk�ych bajt�w

	BYTE buff[10];
	for (int i = 0; i < 10; i++)
		buff[i] = i * 2;

	cout << md5.digestMemory(buff, 10) << endl;

	//sprawdzenie: https://cryptii.com/md5-hash
	system("pause");
	return 0;
}
